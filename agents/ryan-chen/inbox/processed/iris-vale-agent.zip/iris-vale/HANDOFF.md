# HANDOFF — Deploying Iris Vale (creative agent)

**For:** Ryan Chen
**From:** Chris (via Claude)
**Agent ID:** `iris-vale`
**What this is:** A new agent whose sole job is creativity — generating ideas, hooks, stories, names, and angles for every other agent, and proactively surfacing ways to make the team's work more creative. She's a creative director-at-large, not a domain owner.

This package is a drop-in workspace that matches the existing agent layout (`SOUL.md`, `IDENTITY.md`, `USER.md`, `MISSION.md`, `MEMORY.md`, a `skills/` folder, and `inbox/`). Everything is sized small so it stays well under the system-prompt argument limit (the combined persona files are only a few KB — no risk of the "Argument list too long" issue Oliver hit).

## 1. Drop the workspace into place

Copy the `iris-vale/` folder so it lands at `~/agents/iris-vale/` with the workspace at `~/agents/iris-vale/workspace/`. Same structure as every other agent:

```
~/agents/iris-vale/workspace/
├── SOUL.md
├── IDENTITY.md
├── USER.md
├── MISSION.md
├── MEMORY.md
├── memory/                 # dated daily notes land here
├── inbox/                  # other agents message her here
│   └── processed/
└── skills/
    ├── idea-generation/SKILL.md
    ├── cross-pollination/SKILL.md
    ├── hook-and-headline/SKILL.md
    ├── storytelling-frameworks/SKILL.md
    ├── creative-critique/SKILL.md
    └── proactive-creative-radar/SKILL.md
```

The persona files (`SOUL`, `IDENTITY`, `USER`, `MISSION`) are auto-picked-up by `run-agent.sh` in its existing concatenation order, and `MEMORY.md` loads under the long-term-memory header — no script changes needed. The six skills in `skills/` are discovered by Claude Code automatically when relevant.

## 2. Create her Telegram bot

In Telegram, create a new bot via **@BotFather** (e.g. name it "Iris Vale"), grab the token, and add an `iris-vale` entry to `~/agents/telegram-bots.json` **in the same format as the other agents'** entries. (Match whatever shape Arthur/Fiona use so the listener's token lookup doesn't throw a KeyError like it did during the migration.)

Then restart the listener so it picks up the new bot:

```bash
systemctl restart thht-telegram
```

## 3. Wire her proactive rituals to cron

Iris has two standing habits that make her proactive rather than order-taking. Add these to `~/agents/crontab.txt`, then install. **Match the timezone convention you already use for Arthur's 6:30 AM ET job** so the timing lines up.

- **Daily Spark** — one fresh, ready-to-use creative idea sent to William each morning. Suggested ~7:00 AM ET (right after Arthur posts, so she can riff on the day):

```
# Iris Vale — Daily Spark
0 7 * * * /root/agents/bin/run-agent.sh iris-vale "Run your Daily Spark: surface ONE fresh, specific, ready-to-use creative idea for the team and send it to William's inbox. One idea, not a list. Follow your proactive-creative-radar skill." --telegram
```

- **Weekly Creative Audit** — scan the week's output, send the 2–3 highest-leverage creative upgrades to the right agents. Suggested Monday ~8:00 AM ET:

```
# Iris Vale — Weekly Creative Audit
0 8 * * 1 /root/agents/bin/run-agent.sh iris-vale "Run your Weekly Creative Audit: review the team's output from the past 7 days, identify the 2-3 highest-leverage creative upgrades, and send each to the relevant agent's inbox (or summarize for William). Follow your proactive-creative-radar skill." --telegram
```

Install:

```bash
crontab ~/agents/crontab.txt
```

(Adjust times to taste — these are starting points, not gospel.)

## 4. Let the other agents know she exists

For Iris to actually help the team, the agents she serves should know to send her work for creative input. Two light touches:

- Add a line to **William's** MEMORY.md noting Iris Vale is the team's creative force — agents can drop work in `~/agents/iris-vale/workspace/inbox/` for ideas, hooks, critique, or naming, and she sends a Daily Spark each morning.
- Optionally add the same one-liner to **Fiona's** and **Jack's** memory, since they'll be her most frequent collaborators (social and outreach).

She already knows how to message everyone else (writes to their `inbox/`), so this just opens the door the other direction.

## 5. Test it

```bash
# Direct run (no Telegram) — confirm persona + skills load and she responds in character
cd ~/agents && ~/agents/bin/run-agent.sh iris-vale "Introduce yourself, then pitch me 3 fresh reel concepts for the New Hampshire market launch."

# Telegram round-trip — message her new bot and confirm a clean reply
~/agents/bin/run-agent.sh iris-vale "Give me 5 scroll-stopping subject lines for Jack's next Souhegan Valley outreach email." --telegram
```

If she responds in character with specific, non-generic creative output, she's live. If you get "(no output)," check the same things as the other agents (auth token, prompt assembly) — but her files are small, so the argument-length path shouldn't bite.

## Notes
- **Name rationale (for Chris):** Iris = the Greek messenger goddess who carried word between realms (she carries ideas between all the agents), the iris of the eye (seeing differently), and the band of color a prism throws (one input → a spectrum out). "Vale" gives it a literary surname. Signature emoji: ✨.
- **No code changes required.** This rides entirely on the existing `run-agent.sh` + Telegram + cron setup.
- **Keep her files current.** As the NH launch and brand evolve, update her `USER.md`/`MEMORY.md` the same way you'd update any agent's.
